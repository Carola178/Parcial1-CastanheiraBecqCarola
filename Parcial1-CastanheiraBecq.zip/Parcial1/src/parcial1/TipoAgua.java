
package parcial1;


public enum TipoAgua {
    AGUA_SALADA,
    AGUA_DULCE
    
}
