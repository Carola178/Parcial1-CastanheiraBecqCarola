package parcial1;


public class Pez extends Especie implements Alimentable, Movible{
    private double longitudMax;

    public Pez(String nombre, String ubicacion, TipoAgua tipoAgua, double longitudMax) {
        super(nombre, ubicacion, tipoAgua);
    }
    
    
    @Override
    public void respirar(){
        System.out.println("Soy un pez y respiro");
    }
    
    
    @Override
    public void reproducirse(){
        System.out.println("Soy un pez y puedo reproducirme");
    }
    
    @Override
    public void alimentar(){
        System.out.println("Soy un pez y puedo alimentarme");
    }
    
    @Override
    public void moverse(){
        System.out.println("Soy un pez y puedo moverme");
    }

    @Override
    public String toString() {
        return super.toString() + "longitudMax=" + longitudMax + '}';
    }
    
    
}
