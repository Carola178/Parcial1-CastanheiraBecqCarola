
package parcial1;


public interface Alimentable {
    
    public abstract void alimentar();
    
}
