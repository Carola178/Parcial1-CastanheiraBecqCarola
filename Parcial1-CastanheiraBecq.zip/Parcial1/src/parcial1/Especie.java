
package parcial1;


public abstract class Especie {
    private String nombre;
    private String ubicacion;
    private TipoAgua tipoAgua;

    public Especie(String nombre, String ubicacion, TipoAgua tipoAgua) {
        this.nombre = nombre;
        this.ubicacion = ubicacion;
        this.tipoAgua = tipoAgua;
    }
    
    public String getNombre(){
        return nombre;
    }
    
    public String getUbicacion(){
        return ubicacion;
    }
    
    public TipoAgua getTipoAgua(){
        return tipoAgua;
    }
      

    public abstract void respirar();
    
    public abstract void reproducirse();
    
    @Override
    public String toString() {
        return "Especie{" + "nombre=" + nombre + ", ubicacion=" + ubicacion + ", tipoAgua=" + tipoAgua + '}';
    }
    
    
    
}
