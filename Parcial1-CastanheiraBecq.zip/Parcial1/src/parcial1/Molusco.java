
package parcial1;


public class Molusco extends Especie implements Alimentable, Movible{
    private TipoConcha tipoConcha;

    public Molusco(String nombre, String ubicacion, TipoAgua tipoAgua, TipoConcha tipoConcha) {
        super(nombre, ubicacion, tipoAgua);
        this.tipoConcha = tipoConcha;
    }
    
    
    
    @Override
    public void respirar(){
        System.out.println("Soy un molusco y respiro");
    }
    
    
    @Override
    public void reproducirse(){
        System.out.println("Soy un molusco y puedo reproducirme");
    }
    
    @Override
    public void alimentar(){
        System.out.println("Soy un molusco y puedo alimentarme");
    }
    
    @Override
    public void moverse(){
        System.out.println("Soy un molusco y puedo moverme");
    }

    @Override
    public String toString() {
        return super.toString() + "tipoConcha=" + tipoConcha + '}';
    }
}
