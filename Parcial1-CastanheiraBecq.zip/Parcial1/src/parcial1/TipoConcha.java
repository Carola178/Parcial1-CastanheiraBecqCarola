
package parcial1;


public enum TipoConcha {
    ESPIRALADA,
    BIVALVA
    
}
