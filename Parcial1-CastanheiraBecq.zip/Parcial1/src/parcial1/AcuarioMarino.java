
package parcial1;
import java.util.ArrayList;


public class AcuarioMarino {
    private ArrayList<Especie> especies = new ArrayList<>();
    
    
    public void agregarEspecie(Especie e) throws EspecieRepetidaException{
        for(Especie existente : especies){
            if(existente.getNombre().equals(e.getNombre()) 
                    && existente.getUbicacion().equals(e.getUbicacion())){
            throw new EspecieRepetidaException();
            }
        }especies.add(e);
    }
    
    public void mostrarEspecies(){
        for(Especie e : especies){
            System.out.println(e);
        }
    }

    public void moverEspecies(){
    for(Especie e : especies){
        if(e instanceof Movible){ // <-- verificamos la interfaz Movible
            ((Movible) e).moverse();
        } else {
            System.out.println(e.getNombre() + " no se puede mover");
        }
    }
}

    
    public void realizarFuncionesBiologicas() {
        for (Especie e : especies) {
            e.respirar();
        if (e instanceof Alimentable) {
                ((Alimentable) e).alimentar();
        }
    }           
}
    public ArrayList<Especie> filtrarPorTipoAgua(TipoAgua tipo) {
        ArrayList<Especie> resultado = new ArrayList<>();
        for (Especie e : especies) {
            if (e.getTipoAgua() == tipo) {
                resultado.add(e);
                System.out.println(e); 
            }
        }
        return resultado;
    }
}

