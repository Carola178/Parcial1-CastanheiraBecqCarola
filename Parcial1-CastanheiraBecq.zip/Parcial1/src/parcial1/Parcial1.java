
package parcial1;

public class Parcial1 {


    public static void main(String[] args) {
        
    //Acuario
        AcuarioMarino ac = new AcuarioMarino();
        
    //Peces
        Pez p1 = new Pez("Pez globo", "Tanque 1", TipoAgua.AGUA_DULCE, 5.0);
        Pez p2 = new Pez("Pez payaso", "Tanque 2", TipoAgua.AGUA_DULCE, 5.0);
        Pez p3 = new Pez("Pez Betta", "Tanque 3", TipoAgua.AGUA_SALADA, 5.0);
        
        
    //Corales
        Coral c1 = new Coral("Coral estrella", "Tanque 3", TipoAgua.AGUA_SALADA, 7);
        Coral c2 = new Coral("Coral petreo", "Tanque 4", TipoAgua.AGUA_SALADA, 8);
        Coral c3 = new Coral("Coral blando", "Tanque 5", TipoAgua.AGUA_DULCE, 5);
        
    //Moluscos
        Molusco m1 = new Molusco("Pulpo", "Tanque 9", TipoAgua.AGUA_DULCE, TipoConcha.BIVALVA);
        Molusco m2 = new Molusco("Caracol marino", "Tanque 8", TipoAgua.AGUA_SALADA, TipoConcha.ESPIRALADA);
        Molusco m3 = new Molusco("Pulpo", "Tanque 7", TipoAgua.AGUA_DULCE, TipoConcha.BIVALVA);

    try {
        ac.agregarEspecie(p1);
        ac.agregarEspecie(p2);
        ac.agregarEspecie(p3);
        ac.agregarEspecie(c1);
        ac.agregarEspecie(c2);
        ac.agregarEspecie(c3);
        ac.agregarEspecie(m1);
        ac.agregarEspecie(m2);
        ac.agregarEspecie(m3);
    } catch (EspecieRepetidaException ex) {
        System.out.println("Error: Especie repetida");
    }

    System.out.println("Todas las especies");
    ac.mostrarEspecies();

    System.out.println("------------------------------------------------------------------------");


    System.out.println("Moviendo especies");
    ac.moverEspecies();

    
    System.out.println("Funciones biológicas");
    ac.realizarFuncionesBiologicas();

    System.out.println("------------------------------------------------------------------------");

    
    System.out.println("Especies de agua dulce");
    ac.filtrarPorTipoAgua(TipoAgua.AGUA_DULCE);

    System.out.println("------------------------------------------------------------------------");

    
    System.out.println("Especies de agua salada");
    ac.filtrarPorTipoAgua(TipoAgua.AGUA_SALADA);
    
    }
    
}