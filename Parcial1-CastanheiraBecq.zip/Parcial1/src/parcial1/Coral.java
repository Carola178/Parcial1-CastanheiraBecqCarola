
package parcial1;


public class Coral extends Especie{
    private double profIdealCrecimiento;

    public Coral(String nombre, String ubicacion, TipoAgua tipoAgua, double profIdealCrecimiento) {
        super(nombre, ubicacion, tipoAgua);
        this.profIdealCrecimiento = profIdealCrecimiento;
    }
    
    
    @Override
    public void respirar(){
        System.out.println("Soy un coral y respiro");
    }
    
    
    @Override
    public void reproducirse(){
        System.out.println("Soy un coral y puedo reproducirme");
    }

    @Override
    public String toString() {
        return super.toString() + "profCrecimiento=" + profIdealCrecimiento + '}';
    }

}
