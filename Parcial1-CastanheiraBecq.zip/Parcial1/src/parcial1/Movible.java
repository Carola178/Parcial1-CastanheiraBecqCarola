
package parcial1;


public interface Movible {
    
    public abstract void moverse();
    
}
