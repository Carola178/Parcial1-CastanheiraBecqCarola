
package parcial1;


public class EspecieRepetidaException extends RuntimeException{
    public static final String MESSAGE = "No se puede agregar una especie repetida";
    

    public EspecieRepetidaException(){
        super(MESSAGE);
    }
}
